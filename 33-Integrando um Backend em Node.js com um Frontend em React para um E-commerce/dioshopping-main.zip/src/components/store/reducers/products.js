import productsList from './product';

const PRODUCT = productsList;

export default function products(state = PRODUCT){
    return state;
}
