export * from './GlobalStyle';
