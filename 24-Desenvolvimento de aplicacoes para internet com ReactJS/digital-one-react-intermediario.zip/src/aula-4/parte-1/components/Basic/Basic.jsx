import React from 'react';

const Basic = (props) => (
    <p>Meu nome é {props.name}</p>
)

export default Basic;